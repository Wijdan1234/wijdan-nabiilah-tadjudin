package retrofit;

public class ApiService {

    private static String BASE_URL = "https://jsonplaceholder.typicode.com/posts";
    private static retrofit = null;
    public static ApiEndpoint
}
