package retrofit;

import android.annotation.TargetApi;
import android.telecom.Call;

import androidx.core.view.accessibility.AccessibilityEventCompat;

public interface ApiEndpoint {
    @TargetApi(data.php) Call
}
